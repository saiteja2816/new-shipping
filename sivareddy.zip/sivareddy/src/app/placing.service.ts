import { Injectable } from '@angular/core';
import { PlacingOrder } from './PlacingOrder';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class PlacingService {


placingorder:PlacingOrder
  constructor(private httpClient: HttpClient) {

    this.show().subscribe(data => this.placingorder = data);
  }

  

 
  public show(): Observable<PlacingOrder>
 {
 console.log();
 return this.httpClient.get<PlacingOrder>("http://localhost:8069/orders");
 }



  update(data): Observable<PlacingOrder>
  {
  console.log(data.id);
  return this.httpClient.post<PlacingOrder>("http://localhost:8069/order/",data);
  }
 
 }

